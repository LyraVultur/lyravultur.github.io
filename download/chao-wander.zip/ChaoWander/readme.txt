Chao Wander 0.6
by LyraVultur (lyravultur at gmail dot com)

Take care of a little pet chao that wanders around your screen. Place toys and interact with them, or just let them wander! Lots of parts of this pet can be customised, including their colour, name and the appearance of several toys!

Hold left click on the chao to pet them
Right click and hold on chao, toys, etc to drag them around
Middle click your chao for the menu

The chao's "Mood" (happiness) will slowly lower over time. To raise it, pet them occasionally and let them play with toys sometimes. Waking them up from sleep will also upset them.
The "Belly" (hunger) lowers over time, too. Raise it by placing food for your chao. If Belly is too low, Mood will also drop.

Menu help:

CHAO
Rename: Lets you enter a new name for the chao. The chao doesn't mind what you call them, or how often you change their name.
Recolour: Lets you recolour various parts of the chao, or reset them to default. The "From File" option uses CSV files to specify every colour. Some example ones are provided.

OPTIONS
Sound FX: Turns the audio on or off.
Always On Top: Keeps your chao always on top of other windows, so you can do other things and still see and interact with them.

FOOD
Fruit: Spawns fruit for your chao to eat.
Treats: Spawns sweets for your chao to eat.

TOYS
You can clean up all the toys/drawings as well as spawn them from here. Selecting a toy that is already out will clean up only that toy. 
You can also set a custom image for the ball toy.
Custom TV channels can be created by adding or modifying images in the Images/Channels directory.
Custom crayon drawings can be created by adding or modifying images in the Image/Drawings directory.

HATS
Lets you remove or spawn hats that your chao wears. Not all of them work with all animations presently.

RESET
Restarts the application in case your chao gets glitched.

EXIT
Closes the application